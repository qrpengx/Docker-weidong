;<?php return; ?>
[SQL]
host = 192.168.200.120
user = root
password = b79128b9c1963ed53855ab260c813de0
dbname = gearman
port=3306
